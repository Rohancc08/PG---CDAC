package com.app.dto;

public class GetEmailDto {
	private String email;
	public GetEmailDto() {
		// TODO Auto-generated constructor stub
	}
	public GetEmailDto(String email) {
		super();
		this.email = email;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
}
