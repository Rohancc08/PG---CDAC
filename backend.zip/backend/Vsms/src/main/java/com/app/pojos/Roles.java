package com.app.pojos;

public enum Roles {
	CUSTOMER,ADMIN,MECHANIC,SERVICEADVISOR
}
